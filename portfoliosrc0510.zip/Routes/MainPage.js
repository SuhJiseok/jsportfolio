import React, { useEffect, useRef } from 'react'
import '../styles/MainPage.scss';

import Header from '../components/Header';
import Hitmap from '../components/Hitmap';
import Pagelist from '../components/Pagelist';
import More from '../components/More';
import Sub1 from '../components/Sub1';


function MainPage() {
  const pebbleRef = useRef(null);
  const pebbleWrapRef = useRef(null);

  const paragraph = [
    "이 웹 페이지는 직관적인 인터랙션과 세련된 애니메이션을 통해 사용자 친화적인 탐색을 제공하며, 웹 접근성 지침과 웹표준을 엄격하게 준수합니다. ",
    <br key="1" />,
    "자동 배너 기능과 정교한 알고리즘은 사용자가 원활하게 배너를 제어하고 전환할 수 있게 하여 놀라운 시각 경험을 선사합니다.",
    <br key="2" />,
    "또한, 'Top 버튼'은 부드러운 스크롤 애니메이션으로 웹 페이지 상단으로 빠르게 이동하게 해줍니다. 이러한 기능들은 웹 페이지의 접근성을 높이고 사용자 경험을 향상시킵니다.",
    <br key="3" />,
    "모든 구성 요소는 W3C 유효성 검사를 통과하여 고품질의 웹 경험을 보장합니다. 이 웹 페이지는 사용자에게 탁월한 웹 경험을 선사하는 데 효과적인 역할을 합니다."
    
  ];

  useEffect(() => {
    const handleMouseMove = (event) => {
      const pebble = pebbleRef.current;
      const pebbleWrap = pebbleWrapRef.current;
      const pebbleWrapRect = pebbleWrap.getBoundingClientRect();

      const x = event.clientX - pebbleWrapRect.left - pebble.offsetWidth / 2;
      const y = event.clientY - pebbleWrapRect.top - pebble.offsetHeight / 2;

      const maxX = pebbleWrapRect.width - pebble.offsetWidth;
      const maxY = pebbleWrapRect.height - pebble.offsetHeight;

      pebble.style.transform = `translate(${Math.min(Math.max(x, 0), maxX)}px, ${Math.min(Math.max(y, 0), maxY)}px)`;
    };

    document.addEventListener('mousemove', handleMouseMove);

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);
  return (
    <>
    <div>
    {/* <div className='bgmove'></div>
    <div className='bgmove2'></div> */}
      <Header/>
      <h1 className='mainh1'>트렌디하고<br/>
      유저 중심적인<br/>
      프론트엔드 개발자</h1>
      <div className='content1'>
        <p>디지털 아름다움을 선사하는 프론트엔드 개발자<br/> 사용자의 마음을 사로잡는 웹 경험을 창조합니다.<br/>매력 넘치는 디자인과 혁신적인 기술이 결합된<br/> 세련된 웹 환경으로 여러분의 디지털 무대를 한 단계<br/> 업그레이드합니다.</p>
        <div className='pebblewrap' ref={pebbleWrapRef}>
          <div className='pebble' ref={pebbleRef}>
            <div className='logoimg'></div>
          </div>
        </div>
        <div className='logobtn'>
          <button></button>
          <button></button>
          <button></button>
          <button></button>
          <button></button>
          <button></button>
          <button></button> 
        </div>
      </div>
      <div className='content2'>
        <div>
          <h2>단, 5개월 만의 성과</h2>
          <p>많은 시간과 노력을 투자해 HTML5, CSS3, JavaScript, React, TypeScript, 그리고 Next.js 기술들을 배운 개발자입니다. 사용자 중심의 웹 경험을 만들기 위해 끊임없이 학습하고 도전하는 것이 제 열정입니다. 이러한 최첨단 기술들을 통해 디지털 환경에서 여러분의 웹 경험를 높일 수 있는 솔루션을 제공하고자 합니다.</p>
        </div>
      </div>
    </div>
    <Hitmap/>
    <Pagelist/>
    <More/>
    <div className='content3'>
      <div className='content3inner'>
        <div className='imac'>
          <video width={700} height={400} muted autoPlay controls loop>
            <source src=".../public/video/samsungem.mp4" type="video/mp4"></source>
          </video>
        </div>
        <Sub1 h2="삼성전기"  p={paragraph} />
      </div>
      <h2><span>아름다움</span>과 <span>사용성</span>이 공존하는 웹 경험.</h2>
    </div>
    </>
  )
}

export default MainPage