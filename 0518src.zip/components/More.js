import React from 'react'
import '../styles/More.scss';
function More() {
  return (
    <div className='more'>
      <div>
        <h2>Skills and Accessibility checks</h2>
        <h3>See Detail Pages<br/>&<br/>More</h3>
      </div>
    </div>
  )
}

export default More