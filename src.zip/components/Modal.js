import React, { useEffect } from 'react'
import '../styles/Modal.scss';

function Modal({ modalClosing, closeModal }) {
  useEffect(() => {
    if (modalClosing) {
      const timer = setTimeout(closeModal, 500); // Adjust to match animation duration
      return () => clearTimeout(timer);
    }
  }, [modalClosing, closeModal]);

  return (
    <div className={`modal ${modalClosing ? 'modal-closing' : ''}`}>
      <h2>Modal Title</h2>
      <p>Modal content...</p>
      <button onClick={closeModal}>Close</button>
    </div>
  );
}

export default Modal;