import React from 'react'
import '../styles/Bgmove.scss'
function Bgmove() {
  return (
    <div class="bg">
    <span className='ball1'></span>
    <span className='ball2'></span>
    <span className='ball3'></span>
    <span className='ball4'></span>
    <span className='ball5'></span>
    <span className='ball6'></span>
    <span className='ball7'></span>
    <span className='ball8'></span>
    <span className='ball9'></span>
    <span className='ball10'></span>
 </div>
  )
}

export default Bgmove