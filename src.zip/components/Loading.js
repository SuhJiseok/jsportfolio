import React from 'react'
import '../styles/Loading.scss';

function Loading() {
  return (
    
  <section className='loadingsection' >
      <div className="loader">로딩 중입니다..</div>
  </section>

  )
}

export default Loading