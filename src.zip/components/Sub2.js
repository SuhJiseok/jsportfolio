import React from 'react'
import '../styles/Sub2.scss';
import Magic from './Magic';


function Sub2() {
  return (
    <>
    <div className='sub2_1'>
      <h2>리액트 훅스로 멋진 영화 추천 경험 제공.</h2>
      <p>이 멋진 리액트 프로젝트에서는 Row 컴포넌트를 통해 각 영화의 매력을 세련되게 전달하고 있습니다. 프로젝트는<span> useEffect </span>훅을 사용하여 영화 정보를 신선하게 유지하며,<span> API</span>에서 영화 데이터를 가져오는 함수인<span> fetchMovieData</span>를 호출합니다.</p>
    </div>

    <div className='content3inner'>
      <div></div>
      <div className='dvcontainer'>
        <div className='imac'>
          <img src={require(`../images/imac.png`)} alt=""></img>
          <div className='videocontainer'>
            <video autoPlay muted loop preoload>
              <source src="jsportfolio/video/netflixpc.mp4" type='video/mp4'></source>
            </video>
          </div>
        </div>
      </div>
    </div>

    <h2>리액트의 <span><Magic /></span> 영화 검색, 영화 찾기 업그레이드 </h2>

    </>
    
  )
}

export default Sub2