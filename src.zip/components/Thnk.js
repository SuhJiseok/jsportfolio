import React from 'react'
import '../styles/Thnk.scss';


function Thnk() {
  return (
<div class="parent">
  <div class="child">
    <div class="thnkcontainer">
      <span class="slide-text-right">Thank You.</span>
      <span class="slide-text-right">Thank You.</span>
      <span class="slide-text-right">Thank You.</span>
      <span class="slide-text-right">Thank You.</span>     
      
    </div>
  </div>
</div>
  )
}

export default Thnk