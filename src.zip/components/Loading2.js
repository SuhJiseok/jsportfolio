import React, { useEffect, useRef } from "react";
import '../styles/Loading2.scss';




const Loading2 = () => {
  const wrapperRef = React.useRef(null);

  useEffect(() => {
    const SHUFFLING_VALUES = [
      "!", "§", "$", "%",
      "&", "/", "(", ")",
      "=", "?", "_", "<",
      ">", "^", "°", "*",
      "#", "-", ":", ";", "~",
    ];

    const WORDS = [
      "+  -                             -  +",
      "                                     ",
      "                                     ",
      "                                     ",
      "                                     ",
      "|            Loading...             |",
      "                                     ",
      "                                     ",
      "                                     ",
      "                                     ",
      "                                     ",
      "+  -                             -  +",
    ];

    const Loop = function() {
      this._idRAF = -1;
      this._count = 0;
      this._listeners = [];
      this._binds = {};
    
      this._update = function() {
        let listener = null;
        let i = this._count;
        while (--i >= 0) {
          listener = this._listeners[i];
          if (listener) {
            listener.apply(this, null);
          }
        }
        this._idRAF = requestAnimationFrame(this._binds.update);
      }
    
      this._binds.update = this._update.bind(this);
      
      this.start = function() { this._update(); }
      
      this.stop = function() {
        cancelAnimationFrame(this._idRAF);
      }
      
      this.add = function(listener) {
        const idx = this._listeners.indexOf(listener);
        if (idx >= 0) {
          return;
        }
        this._listeners.push(listener);
        this._count++;
      }
      
      this.remove = function(listener) {
        const idx = this._listeners.indexOf(listener);
        if (idx < 0) {
          return;
        }
        this._listeners.splice(idx, 1);
        this._count--;
      }
    };
    const loop = new Loop();
    loop.start();

    const LetterShuffler =  function(wrapper, letter, { duration = 30 } = {}) {
      this.SHUFFLING_VALUES = [
          "!", "§", "$", "%",
          "&", "/", "(", ")",
          "=", "?", "_", "<",
          ">", "^", "°", "*",
          "#", "-", ":", ";", "~",
      ];
      this.id = Math.random();
      this.animate = false;
  
      this.wrapper = wrapper;
      this.letter = letter;
      this.letterToShown = this.letter;
      this.wrapper.innerHTML = '';
      this.timer = 0;
      this.duration = 30;
      this.scaleTargeted = 2;
  
      this.show = function(letter = this.letter) {
          this.animate = true;
          this.timer = 0;
          this.letterToShown = letter;
          loop.add(this.update);
      }
  
      this.hide = function() {
          this.show('');
      }
  
      this.update = function() {
          if (this.animate) {
              this.timer++;
              if (this.timer < this.duration) {
                  this.wrapper.innerHTML = this.SHUFFLING_VALUES[Math.floor(Math.random() * this.SHUFFLING_VALUES.length)];
                  this.wrapper.style.transform = `scale(${(this.timer / this.duration) * 0.9})`;
              } else {
                  this.wrapper.innerHTML = this.letterToShown;
                  loop.remove(this.update);
              }
          }
      }
  

      if (/[+\-| ]/.test(letter)) {
          this.wrapper.classList.add('purple');
      } else {
          this.duration *= 2.1;
      }
  };
    const WordShuffler = function(wrapper, words, { duration = 0.2 } = {}) {
      this.wrapper = wrapper;
      this.wrapper.innerHTML = '';
    
      this.timer = 0;
      this.lettersShown = 0;
      this.letterDuration = duration * 60;
      this.lettersShuffler = [];
      this.arrayOfLetters = [...words];
      this.duration = this.letterDuration * this.arrayOfLetters.length;
    
      this.arrayOfLetters.forEach((letter) => {
        const letterWrapper = document.createElement('span');
        this.wrapper.appendChild(letterWrapper);
        const letterShuffler = new LetterShuffler(letterWrapper, letter, {
          duration: this.letterDuration,
        });
        this.lettersShuffler.push(letterShuffler);
      });
    
      this.show = function() {
        this.timer = 0;
        this.lettersShown = 0;
        loop.add(this.update);
      }
    
      this.update = function() {
        this.timer += 1;
        if (this.timer > (this.letterDuration * this.lettersShown)) {
          this.lettersShuffler[this.lettersShown].show();
          this.lettersShown += 1;
        }
    
        if (this.timer >= this.duration) {
          loop.remove(this.update);
        }
      }
    };
    const TextShuffler = function(wrapper, lines) {
      this.i = 0;
      this.lines = [];
      this.durationInterval = 50;
      this.wrapper = wrapper;
      
      for (let i = 0; i < lines.length; i++) {
        this.lines.push(this._addLine(lines[i]));
      }
    
      this._addLine = function(line) {
        const lineElm = document.createElement('p');
        this.wrapper.appendChild(lineElm);
        const word = new WordShuffler(lineElm, line, { duration: 0.05 });
        return word;
      }
    
      this.show = function() {
        this.i = 0;
        const interval = setInterval(() => {
          this.lines[this.i].show();
          this.i += 1;
    
          if (this.i === this.lines.length) {
            clearInterval(interval);
          }
        }, this.durationInterval);
      }
    
      this.hide = function() {
      }
    };

    const wrapper = wrapperRef.current;
    const text = new TextShuffler(wrapper, WORDS);
    text.show();

    let show = true;
    const interval = setInterval(() => {
      if (show) {
        text.show();
      } else {
        text.hide();
      }
      show = !show;
    }, 4000);

    return () => {
      loop.stop();
      clearInterval(interval);
    };
  }, []);
  return (
    <>
  <div className="wrapper" ref={wrapperRef} />
    </>
  );
};
export default Loading2